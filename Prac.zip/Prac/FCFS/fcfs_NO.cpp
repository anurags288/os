
#include<iostream>
#include<iomanip>
using namespace std;
class fcfs
{
	public:
		int burst_tm, wait_tm, turn_tm ,arr_tm;
		char pid;
};

int main()
{
	int n,i,k,sum=0;
	cout<<"Enter number of processes"<<endl;
	cin>>n;
	fcfs temp;
	fcfs f[10];
	for(i=0;i<n;i++)
	{
	cout<<"Enter process id for the processes"<<endl;
	cin>>f[i].pid;
	cout<<"Enter burst time "<<endl;
	cin>>f[i].burst_tm;
	cout<<"Enter Arrival Time"<<endl;
	cin>>f[i].arr_tm;
}

for(k=0;k<n;k++)
{
	temp=f[k];
	for(i=k+1;i<n;i++)
	{
	if(temp.arr_tm>f[i].arr_tm)
	{
		temp=f[i];
		f[i]=f[k];
		f[k]=f[i];
	}
}
}

float avg_wait_tm=0, avg_Turn_tm=0;
for(k=0;k<n;k++)
{
	f[k].wait_tm= sum-f[k].arr_tm;
	if(f[k].wait_tm<0)
	f[k].wait_tm=0;
	sum+=f[k].burst_tm;
	f[k].turn_tm=sum-f[k].arr_tm;
	avg_wait_tm+=f[k].wait_tm;
	avg_Turn_tm+=f[k].wait_tm+f[k].burst_tm;
}

avg_wait_tm/=n;
avg_Turn_tm/=n;

cout<<setw(4)<<"PROCESS : "<<setw(4)<<"Wait Time"<<setw(4)<<"TurnAround Time"<<setw(4)<<endl;

for(i=0;i<n;i++)
{
cout<<setw(4)<<f[i].pid<<setw(4)<<f[i].wait_tm<<setw(4)<<f[i].turn_tm<<setw(4)<<endl;
}
cout<<"Average Wait Time "<<avg_wait_tm<<endl;
cout<<"Average TurnAround Time"<<avg_Turn_tm<<endl;

return 0;
}
