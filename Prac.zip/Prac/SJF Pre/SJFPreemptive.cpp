#include<iostream>
#include<iomanip>
using namespace std;
class sched{
	public: int bt[10],at[10],wt[10],tat[10],rs[10],done[10],finish[10],rt[10],twt,ttat,total,n;
	void read();
	void Initialize();
	int getNextProcess(int);
	void show();
	void computeSJF();
};

void sched::read()
{
	
    cout<<"Enter no. of processes\n";
    cin>>n;
    cout<<"Enter the burst times in order :\n";
    for(int i=0;i<n;i++)
    cin>>bt[i];
    cout<<"Enter the arrival times in order:\n";
    for(int i=0;i<n;i++)
    cin>>at[i];
}

void sched::Initialize()
{
	  total=0;
    twt=0;
    ttat=0;
    for(int i=0; i<n; i++)
     {   done[i]=0;
        rt[i]=bt[i];
        finish[i]=0;
        wt[i]=0;
        rs[i]=0;
        tat[i]=0;
        total+=bt[i];
        }
}

void sched::computeSJF()
{
	read();
	Initialize();
	int time,i,k,old,next=0;
	for(time=0;time<total;time++)
	{
		old=next;
		next=getNextProcess(time);
		if((old!=next)||(time==0))
		{
			 cout<<"("<<time<<")|==P"<<next+1<<"==|";
		}
		rt[next]=rt[next]-1;
		if(rt[next]==0)
		{
			finish[next]=1;
		}
		
		for(i=0;i<n;i++)
		
			if(i!=next && finish[i]==0 && at[i]<=time)
               {
			   wt[i]++;
			   		}
			   	}
			   	cout<<"("<<total<<")"<<endl;
			   	show();
	}
	
	int sched::getNextProcess(int time)
	{
		int low,i;
		for(i=0;i<n;i++)
		if(finish[i]==0)
		{low=i;
		break;
		}
		for(i=0;i<n;i++)
		{  if(finish[i]!=1)
			if(rt[i]<rt[low] && at[i]<=time)
			low=i;
			if(done[low]==0)
			{
				rs[low]=time;
				rs[low]-=at[low];
				done[low]=1;
			}
		}
	return low;
	}
	
	void sched::show()
	{
		 cout<<setw(5)<<"Process"<<setw(5)<<"Waiting Time"<<setw(5)<<"Turnaround Time"<<setw(5)<<"Response Time"<<endl;
    for(int i=0;i<n;i++)
    {
        twt+=wt[i];
        tat[i]=wt[i]+bt[i];
        ttat+=tat[i];
       
        cout<<setw(5)<<(i+1)<<setw(5)<<wt[i]<<setw(5)<<tat[i]<<setw(5)<<rs[i]<<endl;
    }
    cout<<"Avg Waiting time = "<<(double)twt/n<<" and Avg Turnaround time = "<<(double)ttat/n<<endl;
    cout<<"Scheduling complete\n";
	}
	
	int main()
	{
		sched s;
		s.computeSJF();
		return 0;
	}

