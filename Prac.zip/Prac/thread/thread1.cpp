               /*Thread Program - Resource sharing*/
#include<iostream>
#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>

using namespace std;              
int sum=0;

	void *runner(void *p)
	{
		int n=*((int *)p);
		sum=(n*(n+1))/2;     //sum of n numbers
		pthread_exit(0);
	}

  int main(int argc,char* argv[])
  {
		pthread_t tid;   // another thread's Id
		int num;
		if(argc!=2)
		{
			cout<<endl<<" Enter the value for num = ";
			cin>>num;
		}
		else
			sscanf(argv[1],"%d",&num);           //works for chnaging character to integer 
		if(num<0)
		{
			cout<<endl<<" Value of num shouldn't be negative";
			exit(0);
		}
	pthread_create(&tid,NULL,runner,&num);                   //create new thread by grabbing its regernce
	pthread_join(tid,NULL);           //wait till it terminates
	cout<<endl<<sum<<endl;
   }

