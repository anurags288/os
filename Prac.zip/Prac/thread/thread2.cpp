                 /* Thread 2nd program */
#include<iostream>
#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>

using namespace std;
int sum=0;

class LibBook
{
	string name;
	int cost;
	int code;
public:

	LibBook()
	{
		name="Null";
		cost=0;
		code=0;
	}

	void read()
	{
		cout<<"\n Enter the Book Code = ";
		cin>>code;
		cout<<"\n Enter the Book Name: ";
		cin>>name;
		cout<<"\n Enter the Book Cost :";
		cin>>cost;
	}

	void display()
	{
		cout<<"\n Code: "<<code;
		cout<<"\n Name: "<<name;
		cout<<"\n Cost: "<<cost<<endl;
	}

};

	void *runner(void *p)
	{
		LibBook num=*((LibBook *)p);
		num.display();
		pthread_exit(0);
	}

int main(int argc,char* argv[])
{
	pthread_t tid;
	LibBook lib;
	lib.read();
	pthread_create(&tid,NULL,runner,&lib);
	pthread_join(tid,NULL);

}

