#include<iostream>
#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>
using namespace std;
/* intermixing of threads */

void *runner1(void *param)
{
	for(int i=1000;i<1300;i++)
	{
		cout<<i<<endl;
	}
	pthread_exit(0);
}

void *runner2(void *param)
{
	for(int i=400;i<600;i++)
		cout<<i<<endl;
	pthread_exit(0);
}

int main(int argc,char* argv[])
{
	pthread_t tid1;
	pthread_t tid2;
	
	pthread_create(&tid1,NULL,runner1,NULL);
        //pthread_join(tid1,NULL);
	
        pthread_create(&tid2,NULL,runner2,NULL);

	pthread_join(tid1,NULL);

	pthread_join(tid2,NULL);
	
}

