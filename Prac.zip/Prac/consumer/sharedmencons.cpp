#include<unistd.h>
#include<iostream>
#include<fcntl.h>
#include<string.h>
#include<stdio.h>
#include<sys/shm.h>
#include<sys/mman.h>
#include<sys/types.h>
using namespace std;

int main(int argc,char* argv[])
{

   const int s=4096;
   const char* name="os";

int shm_fd;
void* ptr;
while((shm_fd=shm_open(name,O_RDONLY,0666))<0);

 
 
if(shm_fd<0)
 cout<<"INVALID\n";

     ptr=mmap(0,s,PROT_READ,MAP_SHARED,shm_fd,0);
     printf("%s",(char*)ptr);
     shm_unlink(name);
     return 0;
}
