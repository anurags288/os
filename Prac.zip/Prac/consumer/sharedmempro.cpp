#include<unistd.h>
#include<iostream>
#include<fcntl.h>
//#include<sys/types.h>
#include<string.h>
#include<stdio.h>
#include<sys/shm.h>
#include<sys/mman.h>
using namespace std;

int main(int argc,char* argv[])
{
   const int s=4096;
   const char* name="os";
   const char* m0="hello";
   const char* m1="world";
   
 int shm_fd;
 void *ptr;
 shm_fd=shm_open(name,O_CREAT | O_RDWR,0666);
 if(shm_fd<0)
   cout<<"file not found";


 ftruncate(shm_fd,s);

     ptr=mmap(0,s,PROT_WRITE,MAP_SHARED,shm_fd,0);

cout<<"hello\n";
     sprintf((char*)ptr,"%s",m0);
     ptr=(char*)ptr+strlen(m0);
     sprintf((char*)ptr," %s",m1);


return 0;
}
