#include<iostream>
#include<iomanip>
using namespace std;

class sjf
{
	public:
		int bt,at,temp,wt,tat;
		char pid;
		sjf()
		{
			temp=0;
		}
		
};

int main()
{
	int sum=0,carry=0,i,k,n;
	double avgWt=0, avgTat=0;
	cout<<"enter no of processes"<<endl;
	cin>>n;
	sjf s[10];
	sjf temp;
	for(i=0;i<n;i++)
	{
		cout<<"Enter Process pid"<<endl;
		cin>>s[i].pid;
		cout<<"Enter burst time of each process"<<endl;
		cin>>s[i].bt;
		cout<<"Enter arrival time"<<endl;
		cin>>s[i].at;
	}
	
	for(k=0;k<n;k++)
	{
		temp=s[k];
		for(i=k+1;i<n;i++)
		{
			if(temp.at>s[i].at)
			{
				temp=s[i];
				s[i]=s[k];
				s[k]=temp;
			}
		}
	}
	cout<<"Entered info is as follows"<<endl;
	i=0;
	for(k=1;k<n;k++)
	{
		carry=s[0].at;
	if(s[k].at==carry)
	{
		if(s[k].bt<s[i].bt)
		i=k;
	}
	else
	break;
	}
	
	int tem=0,b,j,flag;
	do
	{
		j=0;
		if((s[i].at<=sum)&&(s[i].temp!=1))
		{
			s[i].wt=sum-s[i].at;
			sum+=s[i].bt;
			s[i].temp=1;
		}
		else
		{
			if(tem==0)
			{
				sum=s[i].at;
				tem=1;
				
			}
			s[i].wt=sum-s[i].at;
			sum+=s[i].bt;
			s[i].temp=1;
		}
		
		flag=1;
		for(k=0;k<n;k++)
		{
			if(s[k].at<=sum)
			{
				if(s[k].temp==1)
				j++;
				else if((s[k].bt<s[i].bt)||(s[i].temp==1))
				{
					i=k;
					flag=0;
				}
			}
		}
		
		if((flag==1)&&(j!=n-1))
		{
			
                                        for(b=i;b<n;b++)
                                        if(!s[b].temp)
                                        {
                                                      carry=s[b].at;
                                                      i=b;
                                                      break;
                                        }
                                        for(int t=b+1;t<n;t++)
                                        {
                                                if(s[t].at==carry)
                                                {
                                                                      if(s[t].bt<s[i].bt)
                                                                                                     i=t;
                                                }
                                                else
                                                break;
                                        }
                 }
     }while(j!=n);
		
 cout<<setw(5)<< "Pocess Pid "<<setw(5)<<"Wait Time "<<setw(5)<<"TurnAround Time " << setw(5)<<endl;                             
     for(k=0;k<n;k++)
     { s[k].tat=s[k].wt+s[k].bt;
                    
                   
				   cout<<setw(5)<<s[k].pid<<setw(5)<<s[k].wt<<setw(5)<<s[k].tat<<setw(5)<<endl;
				     avgWt+=s[k].wt;
                     avgTat+=s[k].wt+s[k].bt;
                    
                    
     }
     avgWt/=n;
     avgTat/=n;
     cout<<"average turn around time:\n"<<avgTat<<endl<<"average waiting time:\n"<<avgWt<<endl;	
return 0;	
}
