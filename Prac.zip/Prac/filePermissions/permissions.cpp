#include<unistd.h>
#include<iostream>
#include<fcntl.h>
#include<stdio.h>
#include<sys/stat.h>
#include<time.h>
#include<sys/types.h>
#include<pwd.h>
using namespace std;

char permission(int v)
{
	if(v==1)
	return 'r';
	else if(v==2)
	return 'w'
	else if(v==3)
	return 'x';
	else
	return '_';
}

int main(int argc, char* argv[])
{
	struct stat a;
	char filename[10];
	int mask=0x0100;
	int count=1;
	
	if(argc!=2)
	{
		cout<<"Enter filename"<<endl;
		cin>>filename;
	}
	else
	{
		strcpy(filename, argv[1]);
		}
		if(stat(filename, &a)<0)
		{
			cout<<"File not found"<<endl;
		}
		else
		{
			while(mask!=0)
			{
				char ch=permission(count);
				
				if((a.st_mode&mask)!=0)
				{
					cout<<ch;
				}
				else
				{
					cout<<'_';
				}
				++count;
				if(count>3)
				{
					count=1;
				}
				mask>>=1;
			}
		}
	}
	
	struct tm* tp=localtime(&a.st_atime);
	cout<<tp->tm_sec<<":"<<tp->tm_min<<":"<<tp->tm_hour<<tp->tm_year+1900<<endl;
	struct tm* t1=localtime(&a.st_mtime);
	cout<<t1->tm_sec<<":"<<t1->tm_min<<":"<<t1->tm_year+1900<<endl;
	struct tm* t2=localtime(&a.st_ctime);
	cout<<t2->tm_sec<<":"<<t2->tm_min<<":"<<t2->tm_year+1900<<endl;
	
	struct passwd* pass;
	pass=getpwuid(a.st_uid);
	cout<<"Name"<<pass->pw_name;
}
