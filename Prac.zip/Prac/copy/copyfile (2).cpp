#include<unistd.h>
#include<iostream>
#include<fcntl.h>
#include<string.h>
#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<sys/wait.h>
using namespace std;

int main(int argc,char* argv[])
{
  int pipe1[2],pipe2[2],pipe3[2];
int n;

  if((pipe(pipe1)<0)||(pipe(pipe2)<0))
     {cout<<"\nno data avaliable";}

char a[6];
  int pid=fork();
  
    if(pid==0)
      { 
        cout<<"enter file name\n";
        cin>>a;
        close(pipe1[0]);
        close(pipe2[1]);
        //close(pipe3[1]);
        write(pipe1[1],a,strlen(a)+1);
          cout<<"child read\n";
       n=read(pipe2[0],a,sizeof(a));
       cout<<"child write\n";
       //n=read(pipe3[0],a,sizeof(a));
        while(n!=0)
        {
           write(1,a,n);
           //cout<<"hello"<<n<<endl;
           n=read(pipe2[0],a,sizeof(a));
           
        }
//close(pipe1[1]);
//close(pipe2[0]);
//close(pipe3[0]);
   
}      

  else
  {
      close(pipe1[1]);
     close(pipe2[0]);
//close(pipe3[0]);
        cout<<"parent write1\n";
     n=read(pipe1[0],a,sizeof(a));
     //cout<<a;
cout<<"parent re4ad\n";
     int fd=open(a,O_RDONLY);
  if(fd<0)
  {
    cout<<"file not found";
    return 0;
  }
     n=read(fd,a,sizeof(a));

      while(n!=0)
        {
           //write(1,a,n);
            //cout<<n;
           write(pipe2[1],a,n);
          // write(pipe3[1],a,n);
           n=read(fd,a,sizeof(a));
           
        }
cout<<"parent write\n";
        close(fd);
close(pipe1[0]);
 close(pipe2[1]);
//close(pipe3[1]);
        }
return 0;

}
