#include<sys/unistd.h>
#include<iostream>
#include<sys/fcntl.h>
#include<string.h>

using namespace std;
int main(int argc,char* argv[])
{
   char sf[10],tf[10];

   if(argc!=3)
   {

      cout<<" enter Source file name ";
      cin>>sf;
      cout<<"enter Destination file";
      cin>>tf;
   }
   else
   {

     strcpy(sf,argv[1]);
    strcpy(tf,argv[2]);
   }
int sd=open(sf,O_CREAT|O_RDWR);
int td=open(tf,O_CREAT|O_WRONLY,0640);
char a[5];
int n;
  while((n=read(sd,a,sizeof(a)))!=0)
   {
      //write(td,a,sizeof(a));
      //write(1,a,sizeof(a));
      write(1,a,n);
      write(td,a,n);
   }
/*while((n=read(sd,a,sizeof(a)-1))!=0)
   {
      a[sizeof(a)-1]='\0';
      cout<<a;
   }*/

}
