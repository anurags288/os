#include<iostream>
#include<fstream>
#include<string>
#include<sys/sysinfo.h>
#include<cstdlib>
using namespace std;
int main()
  {
     string str1="processor",str2="vendor_id",str3="model name";
      string str;
      ifstream fin;
     char ch;
     fin.open("/proc/sys/kernel/version");  //for version
         if(!fin)
           {
               cerr<<"COULD NOT OPEN FILE \n";
               exit(100);
            }
       while(fin.get(ch))
        {

          //  cout<<"char:"<<ch<<":"<<endl;
             if(ch=='S')
                break;
            cout<<ch;
         }
     fin.close();


       fin.open("/proc/cpuinfo");  //for cpuinfo
         if(!fin)
           {
               cerr<<"COULD NOT OPEN FILE \n";
               exit(100);
            }
       while(getline(fin,str))
        {

           if((str.substr(0,9)).compare(str1)==0)
                {
                     cout<<endl;
                 cout<<str<<endl;
              }

           if((str.substr(0,9)).compare(str2)==0)
              cout<<str<<endl;

           if((str.substr(0,10)).compare(str3)==0)
              cout<<str<<endl;
                     /* if((str1.find(str,0))!=string::npos)
           cout<<str<<endl;
          else if((str2.find(str,0))!=string::npos)

            cout<<str<<endl;
          else if((str1.find(str,0))!=string::npos)

           cout<<str<<endl;*/
         }
     fin.close();



   struct sysinfo a;
    if(sysinfo(&a)<0)
     cout<<"ERROR \n";

   cout<<"\nTOTAL RAM : ";
   cout<<(a.totalram)/1000<<" KB \n";
  cout<<"\nFREE RAM : ";
   cout<<(a.freeram)/1000<<" KB \n";
   cout<<"\nSHARED RAM : ";
   cout<<(a.sharedram)/1000<< "KB \n";
   cout<<"\nBUFFER RAM : ";
   cout<<(a.bufferram)/1000<< " KB \n";
    cout<<"\nTOTAL SWAP : ";
   cout<<(a.totalswap)/1000<<" KB \n";
   cout<<"\nFREE SWAP : ";
   cout<<(a.freeswap)/1000<<" KB \n";
   cout<<"\nUSED RAM  : ";
   cout<<(a.totalram-(a.freeram+a.sharedram+a.bufferram))/1000<<" KB \n";
   return 0;
 }
