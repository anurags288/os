#include <iostream>
using namespace std;
class Process
  {
      public:
     int process_no;
      int burst_time;
      int arrival_time;
       int turnaround_time;
        int wait_time;
        int response_time;
         int priority;
         int r;
      
     int finish;
     void input();
   
     void display();
   void computeP(int n,int total,Process a[]);
    int Init(int n,Process a[]);
    void dispTime(int n,Process a[]);
    int getNextProcess(int,int,Process a[]);
   
   };
 
  void Process::input()
   {
     cout<<"ENTER THE PROCESS NO. : ";
     cin>>process_no;
      cout<<"ENTER THE ARRIVAL TIME FOR PROCESS "<<process_no <<" : ";
        cin>>arrival_time;
      cout<<"ENTER THE BURST TIME FOR PROCESS "<<process_no<<" : ";
    
        cin>>burst_time;
       cout<<"ENTER THE PRIORITY OF THE PROCESS "<<process_no<<" : ";
      cin>>priority;
   }

int Process::Init(int n,Process a[]){
   int total=0;
  
    for(int i=0; i<n; i++){
        a[i].response_time=a[i].burst_time;
        a[i].finish=0;
         a[i].wait_time=0;
        total+=a[i].burst_time;
        }
 return total;
}
 
void Process::computeP(int n,int total,Process a[]){
    
   
    int time,next=0,old,i,j=0;
     int seq[total];
    cout<<"sequence\n ";
    for(time=0;time<total;time++)
    {
           int k=0;
        old=next;
        next=getNextProcess(time,n,a);
        if(old!=next || time==0)
          {
           seq[j++]=(next+1);
              for(i=0;i<j;i++)
                  {
                      if( seq[i]==(next+1))
                           k++;
                   }
               if(k==1)
                a[next].r=time;
                          
         // cout<<"("<<time<<")| P"<<next+1<<" |";
 }
        a[next].response_time=a[next].response_time-1;
        if(a[next].response_time==0) a[next].finish=1;
        for(i=0;i<n;i++)
            if(i!=next && a[i].finish==0 && a[i].arrival_time<=time)
                a[i].wait_time++;
 
    }
    cout<<"("<<total<<")"<<endl;
 
    for(i=0;i<n;i++)
        if(!a[i].finish) {cout<<"Scheduling failed, cannot continue\n"; return;}
 
 for(i=0;i<total;i++)
          {
             int no=seq[i];
                 if(no/10!=0)
                     break;
                  cout<<"Process "<<seq[i]<<"->";}
    cout<<endl;
                   
    dispTime(n,a);
    
 
}
 
 void Process::display()
  {
    cout<<" PROCESS "<<process_no<<"             "<<arrival_time<<"            "<<burst_time<<"                    "<<turnaround_time<<"                          "<<wait_time<<"                   "<<response_time<<endl;
    }
void Process::dispTime(int n,Process a[])
{
 cout<<"                ARRIVAL TIME      BURST TIME           TURNAROUND TIME          WAIT TIME         RESPONSE TIME\n";
   int i,twt=0,ttat=0;
 
    for( i=0;i<n;i++)
    {
          
        twt+=a[i].wait_time;
        a[i].turnaround_time=a[i].wait_time+a[i].burst_time;
        ttat+=a[i].turnaround_time;
       a[i].response_time=a[i].r-a[i].arrival_time;
     }
    for(i=0;i<n;i++){
      a[i].display();
      }
 
    cout<<"Avg Waiting time = "<<(double)twt/n<<" and Avg Turnaround time = "<<(double)ttat/n<<endl;
    
}
 
int Process::getNextProcess(int time,int n,Process a[]){
 
        int i,low;
        for(i=0;i<n;i++)
            if(a[i].finish==0){low=i; break; }
        for(i=0;i<n;i++)
            if(a[i].finish!=1)
                if(a[i].priority>a[low].priority && a[i].arrival_time<=time)
                        low=i;
        return low;
 
}
 

 
int main()
{
   int n,i,j;
     
     cout<<"ENTER THE NO OF PROCESSES \n";
        cin>>n;
     
    Process a[n];
    Process ob;

     for( i=0;i<n;i++)
      a[i].input();
    
   int total= ob.Init(n,a);
           ob.computeP(n,total,a);

  
 
}
